import sys
import pygame
import random
import os
from random import randint

# Ensure audio driver does not block on some systems
os.environ['SDL_AUDIODRIVER'] = 'dsp'

# Initialize pygame
pygame.init()
size = width, height = 800, 800
screen = pygame.display.set_mode(size)
pygame.font.init()

# Load and scale assets
background = pygame.image.load('background.png')
background = pygame.transform.scale(background, (width, height))
player_size = 100  # Example player size
player_image = pygame.image.load('player.png')
player_image = pygame.transform.scale(player_image, (player_size, player_size))
tree_image = pygame.image.load('tree.png')
tree_image = pygame.transform.scale(tree_image, (150, 150))

# Player speed
player_speed = 5

# Sprite Group
camera_group = pygame.sprite.Group()

# Clock
clock = pygame.time.Clock()

# Tree Sprite Class
class Tree(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = tree_image
        self.rect = self.image.get_rect(topleft=(x, y))

# Player Sprite Class
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = player_image
        self.rect = self.image.get_rect(center=(width // 2, height // 2))

    def update(self, keys):
        if keys[pygame.K_LEFT] or keys[ord('a')]:
            self.rect.x -= player_speed
        if keys[pygame.K_RIGHT] or keys[ord('d')]:
            self.rect.x += player_speed
        if keys[pygame.K_UP] or keys[ord('w')]:
            self.rect.y -= player_speed
        if keys[pygame.K_DOWN] or keys[ord('s')]:
            self.rect.y += player_speed

        # Clamp to screen
        self.rect.x = max(0, min(self.rect.x, width - player_size))
        self.rect.y = max(0, min(self.rect.y, height - player_size))

# Create player instance and add to group
player_sprite = Player()
camera_group.add(player_sprite)

# Create trees
for _ in range(18):
    random_x = randint(0, width - 150)
    random_y = randint(0, height - 150)
    tree_sprite = Tree(random_x, random_y)
    camera_group.add(tree_sprite)

# Main game loop
main = True
while main:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    
    # Get the keys currently pressed
    keys = pygame.key.get_pressed()

    # Update all sprites (player uses keys)
    player_sprite.update(keys)

    # Draw the background
    screen.blit(background, (0, 0))

    # Draw all sprites
    camera_group.draw(screen)

    # Update the display
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)